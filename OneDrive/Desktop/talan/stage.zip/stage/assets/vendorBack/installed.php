<?php return array (
  '@hotwired/stimulus' => 
  array (
    'version' => '3.2.2',
    'dependencies' => 
    array (
    ),
    'extraFiles' => 
    array (
    ),
  ),
  '@hotwired/turbo' => 
  array (
    'version' => '7.3.0',
    'dependencies' => 
    array (
    ),
    'extraFiles' => 
    array (
    ),
  ),
);